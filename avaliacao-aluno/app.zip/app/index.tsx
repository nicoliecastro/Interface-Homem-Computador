import React, { useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet } from 'react-native';

export default function App() {
  const [nome, setNome] = useState('');
  const [nota1, setNota1] = useState('');
  const [nota2, setNota2] = useState('');
  const [nota3, setNota3] = useState('');
  const [frequencia, setFrequencia] = useState('');
  const [resultado, setResultado] = useState('');

  function verificarSituacao() {
    const notaNum = (parseFloat(nota1) + parseFloat(nota2) + parseFloat(nota3)) / 3;
    const freqNum = parseFloat(frequencia);

    if (notaNum >= 7 && freqNum >= 75) {
      setResultado(`${nome} está Aprovado! `);
    } else if (notaNum < 7) {
      setResultado(`${nome} está Reprovado por nota. `);
    } else if (freqNum < 75) {
      setResultado(`${nome} está Reprovado por frequência. `);
    }
  }

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Verificação de Aluno</Text>
      
      <TextInput
        style={styles.input}
        value={nome}
        onChangeText={setNome}
        placeholder="Digite o nome"
      />

      <Text style={styles.subTitle}>Notas:</Text>
      <TextInput
        style={styles.input}
        keyboardType="numeric"
        value={nota1}
        onChangeText={setNota1}
        placeholder="Nota 1"
      />
      <TextInput
        style={styles.input}
        keyboardType="numeric"
        value={nota2}
        onChangeText={setNota2}
        placeholder="Nota 2"
      />
      <TextInput
        style={styles.input}
        keyboardType="numeric"
        value={nota3}
        onChangeText={setNota3}
        placeholder="Nota 3"
      />

      <TextInput
        style={[styles.input, styles.frequencia]}
        keyboardType="numeric"
        value={frequencia}
        onChangeText={setFrequencia}
        placeholder="Frequência (%)"
      />
      
      <Button title="Verificar" onPress={verificarSituacao} color="#4169E1" />
      <Text style={styles.resultado}>{resultado}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#87CEFA',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 50,
    color: 'black',
  },
  subTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    alignSelf: 'flex-start',
    marginLeft: '10%',
    marginTop: 15,
    color: 'black',
  },
  input: {
    width: '80%',
    borderWidth: 0,
    borderColor: '#ccc',
    padding: 10,
    marginVertical: 5,
    borderRadius: 5,
    backgroundColor: '#fff',
  },
  frequencia: {
    marginTop: 40,
    marginBottom: 30,
  },
  resultado: {
    fontSize: 20,
    marginTop: 20,
    fontWeight: 'bold',
    color: 'black',
    textAlign: 'center',
  },
});